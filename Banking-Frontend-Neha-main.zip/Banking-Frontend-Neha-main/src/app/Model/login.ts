export class loginModel{
     id:String;
     name :String;
     gender :String;
     father :String;
     mother :String;
     dob :String;
     nominee :String;
     address :String;
     pin :String;
     phone_no :String;
     email :String;
     pancard:String;
     pan_photo :String;
     addharcard :String;
     addhar_photo:String;
     password :String;
     submit_date:String;
     approve:number;
     email_sent:number;
}