export class TransactionModel{
    tranactionId : String;
    senderAccountNo : String;
    sendertotalBalance : number;
    debitedAmount : number;
    reciverAccountNo : String;
    reciverIfsc : String;
    receiverName:String;
    moneyRecivingDate : String;
}