export class BankLoginModel{
    user_id:String;
    email:String;
    password:String;
    role:String;
}