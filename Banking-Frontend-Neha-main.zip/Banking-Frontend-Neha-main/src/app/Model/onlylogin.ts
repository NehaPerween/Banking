export class OnlyLogin{

    userID:String;
    password:String;
}