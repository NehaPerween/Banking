export class AccountDetailsModel{

        id : String;
		name : String;
		user_id : String;
		account_number : String;
		ifsc : String;
		totalAmount:number;
		branch_code : String;
		phone_no : String;
		email : String;
		pan : String;
		addhar : String;
		date : String;
}