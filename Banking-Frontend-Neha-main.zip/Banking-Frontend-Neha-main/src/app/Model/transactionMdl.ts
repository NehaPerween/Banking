export class TransactionMdl{
    Id:String;
    debitAmount:number;
    Status:String;
    Date:Date;
    TotalAmount:number;
}